export { default } from '@/pages/settings';
