export { default } from '@/pages/reports';
