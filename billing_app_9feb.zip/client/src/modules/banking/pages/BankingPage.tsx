export { default } from '@/pages/banking';
