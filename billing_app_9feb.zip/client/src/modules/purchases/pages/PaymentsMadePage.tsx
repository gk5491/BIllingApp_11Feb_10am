export { default } from '@/pages/payments-made';
