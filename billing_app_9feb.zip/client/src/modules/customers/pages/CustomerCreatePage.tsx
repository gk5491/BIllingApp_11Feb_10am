export { default } from '@/pages/customer-create';
