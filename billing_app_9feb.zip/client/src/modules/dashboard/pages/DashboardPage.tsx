export { default } from '@/pages/dashboard';
