export { default } from '@/pages/documents';
