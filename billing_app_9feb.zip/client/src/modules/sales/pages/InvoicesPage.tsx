export { default } from '@/pages/invoices';
